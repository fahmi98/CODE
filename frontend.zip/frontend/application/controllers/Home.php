<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
    function __construct()
    {
        parent::__construct();

        $this->load->model('users_model', 'users');
    }

    public function index()
    {
        $this->load->model('kastotal_model', 'kastotal');
        $this->load->model('kasdt_model', 'kasdt');
        $this->load->model('kashd_model', 'kashd');
        $this->load->model('kegiatan_model', 'kegiatan');
        $this->load->helper(['tanggal']);
        $header = ['title' => 'Home'];
        $body = [
            'kastotal' => $this->kastotal->getTotal(date('Y-m-d')),
            'pemasukan' => $this->kasdt->getDataIN(),
            'pengeluaran' => $this->kasdt->getDataOUT(),
            'kashead' => $this->kashd->getDataLastMonth(),
            'kegiatan' => $this->kegiatan->getHomePage()
        ];
        // $data['style'] = get_cookie('style');

        $this->load->view('templates/header', $header);
        $this->load->view('home/index', $body);
        $this->load->view('templates/footer');
    }

    public function login()
    {
        if (!$this->session->has_userdata('_id')) {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('usernameLogin', 'Username', 'required|max_length[30]');
                $this->form_validation->set_rules('passwordLogin', 'Password', 'required|max_length[10]');
                if (!$this->form_validation->run() == false) {
                    $this->_login();
                } else {
                    redirect('home/login');
                }
            } else {
                $header = ['title' => 'Login'];

                $this->load->view('templates/header', $header);
                $this->load->view('home/login');
                $this->load->view('templates/footer');
            }
        } else {
            redirect(base_url());
        }
    }

    private function _login()
    {
        $email = $this->input->post('usernameLogin', true);
        $password = $this->input->post('passwordLogin', true);

        $check_user = $this->users->getDataLogin($email);
        if ($check_user->num_rows() > 0) {
            $datauser = $check_user->row();
            if ($datauser->iRole == 5) {
                if (password_verify($password, $datauser->vPassword)) {
                    $set_data_user = [
                        '_id' => $datauser->iIdUser,
                        '_username' => $datauser->vUsername,
                        '_email' => $datauser->vEmail,
                        '_nama' => $datauser->vNama,
                        '_role' => $datauser->iRole,
                        '_gender' => $datauser->eGender,
                        '_status' => $datauser->eStatus,
                    ];
                    $this->session->set_userdata($set_data_user);
                    redirect(base_url());
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password Salah</div>');
                    redirect('home/login');
                }
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Terjadi Kesalahan</div>');
                redirect('home/login');
            }
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Email Atau Username Tidak Ditemukan</div>');
            redirect('home/login');
        }
    }

    public function profile()
    {
        if ($this->session->has_userdata('_id')) {
            $this->load->helper(['gender', 'tanggal']);
            $userData = $this->users->getDataById($this->session->userdata('_id'));
            $head = ['title' => 'My Profile'];
            $body = ['dataProfile' => $userData];

            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                if (!$this->input->is_ajax_request()) {
                    $this->form_validation->set_rules('oldPassword', 'Password Lama', 'required|max_length[10]');
                    $this->form_validation->set_rules('newPassword', 'Password Baru', 'required|max_length[10]');

                    if (!$this->form_validation->run() == false) {
                        $oldpass = htmlspecialchars($this->input->post('oldPassword', true));
                        $newpass = htmlspecialchars($this->input->post('newPassword', true));

                        if ($oldpass != $newpass) {
                            if (password_verify($oldpass, $userData->vPassword)) {
                                $dUser = [
                                    'vPassword' => password_hash($newpass, PASSWORD_DEFAULT)
                                ];
                                $updateUser = $this->users->editRecord($this->session->userdata('_id'), $dUser);
                                if ($updateUser > 0) {
                                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Password Telah Diubah</div>');
                                } else {
                                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password Tidak Berubah</div>');
                                }
                            } else {
                                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password Lama Salah</div>');
                            }
                        } else {
                            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password Baru Tidak Boleh Sama Dengan Password Lama</div>');
                        }
                    } else {
                        $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Terjadi Kesalahan Saat Menyimpan Data</div>');
                    }
                } else {
                    $response = ['status' => 403, 'text' => 'Access Denied !'];
                    echo json_encode($response);
                    exit();
                }
            }

            $this->load->view('templates/header', $head);
            $this->load->view('home/profile', $body);
            $this->load->view('templates/footer');
        } else {
            redirect(base_url());
        }
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url());
    }
}
