<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Eror extends CI_Controller
{

    public function index()
    {
        $this->load->view('errors/html/error_general');
    }

    public function error403()
    {
        $this->load->view('errors/custom/error_403');
    }

    public function error404()
    {
        $this->load->view('errors/custom/error_404');
    }
}
