<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kegiatan extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('users_model', 'users');
        $this->load->helper(['tanggal', 'textstyle']);
    }

    public function index()
    {
        if ($this->session->has_userdata('_id')) {
            $this->load->model('pengajian_model', 'pengajian');
            $head = ['title' => 'Pengajian Anggota'];
            $body = ['acara' => $this->pengajian->getDataLimit(),];

            $this->load->view('templates/header', $head);
            $this->load->view('kegiatan/pengajian', $body);
            $this->load->view('templates/footer');
        } else {
            redirect(base_url());
        }
    }

    public function sholat()
    {
        $this->load->model('solat_model', 'solat');
        $head = ['title' => 'Kegiatan Sholat'];
        $body = ['acara' => $this->solat->getDataLimit(), 'bulanan' => $this->solat->getDataMonth()];

        $this->load->view('templates/header', $head);
        $this->load->view('kegiatan/sholat', $body);
        $this->load->view('templates/footer');
    }

    public function acara()
    {
        $this->load->model('acara_model', 'acara');
        $head = ['title' => 'Kegiatan Sholat'];
        $body = ['acara' => $this->acara->getDataLimit(), 'bulanan' => $this->acara->getDataMonth()];

        $this->load->view('templates/header', $head);
        $this->load->view('kegiatan/acara', $body);
        $this->load->view('templates/footer');
    }
}
