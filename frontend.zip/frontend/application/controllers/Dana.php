<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dana extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('users_model', 'users');
        $this->load->helper(['tanggal', 'textstyle']);
    }

    public function index()
    {
        $this->load->model('pemasukan_model', 'pemasukan');
        $head = ['title' => 'Donasi'];
        $body = ['donatur' => $this->pemasukan->getDataDonatur()];

        $this->load->view('templates/header', $head);
        $this->load->view('dana/index', $body);
        $this->load->view('templates/footer');
    }

    public function donasi()
    {
        if ($this->session->has_userdata('_id')) {
            $this->load->model('pemasukan_model', 'pemasukan');
            $this->load->model('rekening_model', 'rekening');
            $this->load->model('listkas_model', 'listkas');

            $head = ['title' => 'Donasi'];
            $body = [
                'donatur' => $this->pemasukan->getDataByDonatur($this->session->userdata('_id')),
                'datarek' => $this->rekening->getListRek(),
                'dlist' => $this->listkas->getListDANA()
            ];
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->load->model('kashd_model', 'kashd');
                $this->form_validation->set_rules('donasiTanggal', 'Tanggal', 'required');
                $this->form_validation->set_rules('donasiJumlah', 'Jumlah', 'required|max_length[11]');

                if (cekMonth($this->input->post('donasiTanggal', true))) {
                    if ($this->kashd->getCheckDate($this->input->post('donasiTanggal', true))) {
                        if (!$this->form_validation->run() == false) {
                            $dPemasukan = [
                                'vNama' => $this->session->userdata('_nama'),
                                'iTotal' => htmlspecialchars($this->input->post('donasiJumlah', true)),
                                'dDate' => htmlspecialchars($this->input->post('donasiTanggal', true)),
                                'eTipePb' => 'BANK',
                                'iRekeningId' => htmlspecialchars($this->input->post('donasiBank', true)),
                                'eTypeKas' => htmlspecialchars($this->input->post('donasiKas', true)),
                                'iCreated' => $this->session->userdata('_id'),
                                'iUpdated' => $this->session->userdata('_id'),
                            ];
                            $addPemasukan = $this->pemasukan->addRecord($dPemasukan);
                            if ($addPemasukan > 0) {
                                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Tersimpan</div>');
                            } else {
                                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Data Tidak Tersimpan</div>');
                            }
                        }
                    } else {
                        $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Data Tidak Tersimpan, Silahkan Hubungi Administrator</div>');
                    }
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Data Tidak Tersimpan, Karena Masa Bulan Sudah Lewat</div>');
                }
            }
            $this->load->view('templates/header', $head);
            $this->load->view('dana/donasi', $body);
            $this->load->view('templates/footer');
        } else {
            redirect(base_url());
        }
    }

    public function kas()
    {
        $this->load->model('kasdt_model', 'kasdt');
        $header = ['title' => 'Kas Masjid'];
        $body = ['danakas' => $this->kasdt->getDataByDate()];

        $this->load->view('templates/header', $header);
        $this->load->view('dana/kas', $body);
        $this->load->view('templates/footer');
    }

    public function infaq()
    {
        $this->load->model('pemasukan_model', 'pemasukan');
        $head = ['title' => 'Infaq'];
        $body = ['donatur' => $this->pemasukan->getDataInfaq()];

        $this->load->view('templates/header', $head);
        $this->load->view('dana/infaq', $body);
        $this->load->view('templates/footer');
    }

    public function sodaqoh()
    {
        $this->load->model('pemasukan_model', 'pemasukan');
        $head = ['title' => 'Sodaqoh'];
        $body = ['donatur' => $this->pemasukan->getDataSodaqoh()];

        $this->load->view('templates/header', $head);
        $this->load->view('dana/sodaqoh', $body);
        $this->load->view('templates/footer');
    }
}
