<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Zakat extends CI_Controller
{

    public $dtable = true;
    function __construct()
    {
        parent::__construct();
        $this->load->model('users_model', 'users');
        $this->load->model('zakat_model', 'zakat');
        $this->load->model('zakatdt_model', 'zakatdt');
        $this->load->helper(['tanggal', 'textstyle']);
    }
    public function index()
    {
        $zakat = $this->zakat->getLastRecord();
        $zakatdt = $this->zakatdt->getDataByHeader($zakat->iIdZakat);
        $head = ['title' => 'Zakat'];
        $body = ['dzakat' => $zakatdt, 'dhead' => $zakat];

        $this->load->view('templates/header', $head);
        $this->load->view('zakat/index', $body);
        $this->load->view('templates/footer');
    }
}
