<?php

class Kasdt_model extends CI_Model
{
    public $table = 'tb_kas_dt';
    public $orderDef = ['iIdKasDt', 'iTotal', 'dDate', null, null, null];

    public function getDataByDate()
    {
        $this->db->select(['tb_kas_dt.dDate', 'GROUP_CONCAT(k.vNama) as tipeKas', 'GROUP_CONCAT(tb_kas_dt.iTotal) as dtTotal']);
        $this->db->from($this->table);
        $this->db->join('tb_list_tk k', 'k.iIdTk = tb_kas_dt.iTipe', 'left');
        $this->db->where('tb_kas_dt.dDate >= ', date('Y-m-d', strtotime('-7 days')));
        // $this->db->where('YEAR(tb_kas_dt.dDate)', date('Y'));
        $this->db->group_by("tb_kas_dt.dDate");
        $query = $this->db->get();

        return $query->result();
    }

    public function getDataIN()
    {
        $month = date('m');
        $year = date('Y');
        $this->db->select(['SUM(iTotal) as intotal']);
        $this->db->from($this->table);
        $this->db->where('MONTH(tb_kas_dt.dDate)', $month);
        $this->db->where('YEAR(tb_kas_dt.dDate)', $year);
        $this->db->where('iTotal > 0');
        $query = $this->db->get();

        return $query->row();
    }

    public function getDataOUT()
    {
        $month = date('m');
        $year = date('Y');
        $this->db->select(['SUM(iTotal) as outtotal']);
        $this->db->from($this->table);
        $this->db->where('MONTH(tb_kas_dt.dDate)', $month);
        $this->db->where('YEAR(tb_kas_dt.dDate)', $year);
        $this->db->where('iTotal < 0');
        $query = $this->db->get();

        return $query->row();
    }

    public function getSumTromol()
    {
        $this->db->select('SUM(tb_kas_dt.iTotal) as kdttotal');
        $this->db->from($this->table);
        $this->db->join('tb_list_tk', 'tb_list_tk.iIdTk = tb_kas_dt.iTipe', 'left');
        if ($_REQUEST) {
            $this->db->where('MONTH(tb_kas_dt.dDate)', $_REQUEST['rBulan']);
            $this->db->where('YEAR(tb_kas_dt.dDate)', $_REQUEST['rTahun']);
        } else {
            $this->db->where('MONTH(tb_kas_dt.dDate)', date('m'));
            $this->db->where('YEAR(tb_kas_dt.dDate)', date('Y'));
        }
        $this->db->where('tb_list_tk.eTipe', 'IN');
        $query = $this->db->get();

        return $query->row();
    }

    public function getSumPM()
    {
        $this->db->select('SUM(tb_kas_dt.iTotal) as kdttotal');
        $this->db->from($this->table);
        $this->db->join('tb_list_tk', 'tb_list_tk.iIdTk = tb_kas_dt.iTipe', 'left');
        if ($_REQUEST) {
            $this->db->where('MONTH(tb_kas_dt.dDate)', $_REQUEST['rBulan']);
            $this->db->where('YEAR(tb_kas_dt.dDate)', $_REQUEST['rTahun']);
        } else {
            $this->db->where('MONTH(tb_kas_dt.dDate)', date('m'));
            $this->db->where('YEAR(tb_kas_dt.dDate)', date('Y'));
        }
        $this->db->where('tb_list_tk.eTipe', 'OUT');
        $query = $this->db->get();

        return $query->row();
    }

    public function getSumDonasi()
    {
        $this->db->select('SUM(tb_kas_dt.iTotal) as kdttotal');
        $this->db->from($this->table);
        $this->db->join('tb_list_tk', 'tb_list_tk.iIdTk = tb_kas_dt.iTipe', 'left');
        if ($_REQUEST) {
            $this->db->where('MONTH(tb_kas_dt.dDate)', $_REQUEST['rBulan']);
            $this->db->where('YEAR(tb_kas_dt.dDate)', $_REQUEST['rTahun']);
        } else {
            $this->db->where('MONTH(tb_kas_dt.dDate)', date('m'));
            $this->db->where('YEAR(tb_kas_dt.dDate)', date('Y'));
        }
        $this->db->where('tb_list_tk.eTipe', 'DANA');
        $query = $this->db->get();

        return $query->row();
    }

    public function getSumBoti()
    {
        $this->db->select('SUM(iTotal) as kdttotal');
        $this->db->from($this->table);
        if ($_REQUEST) {
            $this->db->where('MONTH(dDate)', $_REQUEST['rBulan']);
            $this->db->where('YEAR(dDate)', $_REQUEST['rTahun']);
        } else {
            $this->db->where('MONTH(dDate)', date('m'));
            $this->db->where('YEAR(dDate)', date('Y'));
        }
        $this->db->where('iTipe', '4');
        $query = $this->db->get();

        return $query->row();
    }
}
