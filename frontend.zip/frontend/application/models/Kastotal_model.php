<?php

class Kastotal_model extends CI_Model
{
    public $table = 'tb_total_kas';
    public $orderDef = ['iIdTKas', 'iBulan', 'yTahun', 'iTotal', 'iPrevTotal', 'iCreated'];

    // public function getDataById($id)
    // {
    //     $this->db->select('*');
    //     $this->db->from($this->table);
    //     $this->db->where(['iIdTk' => $id]);
    //     $query = $this->db->get();

    //     return $query->row();
    // }

    public function getTotal($tgl)
    {
        $month = date('m', strtotime($tgl));
        $year = date('y', strtotime($tgl));

        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['iBulan' => $month, 'yTahun' => $year]);
        $query = $this->db->get();

        return $query->row();
    }
}
