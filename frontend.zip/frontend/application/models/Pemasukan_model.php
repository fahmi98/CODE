<?php

class Pemasukan_model extends CI_Model
{
    public $table = 'tb_pemasukan';
    public $orderDef = ['iIdPm', 'vNama', 'iTotal', 'dDate', 'eTipePb', 'iRekeningId', 'eTypeKas', null, 'iConfirm'];

    public function getDataDonatur()
    {
        $this->db->select(['d.*', 'IFNULL(r.vNamaBank,"-") as bank']);
        $this->db->from($this->table . ' d');
        $this->db->join('tb_list_rekening r', 'r.iIdTp = d.iRekeningId', 'left');
        $this->db->where('d.eTypeKas = 1');
        $this->db->where('iConfirm IS NOT NULL');
        $this->db->limit(40);
        $this->db->order_by('iIdPm', 'DESC');
        $query = $this->db->get();

        return $query->result();
    }

    public function getDataInfaq()
    {
        $this->db->select(['d.*', 'IFNULL(r.vNamaBank,"-") as bank']);
        $this->db->from($this->table . ' d');
        $this->db->join('tb_list_rekening r', 'r.iIdTp = d.iRekeningId', 'left');
        $this->db->where('d.eTypeKas = 2');
        $this->db->where('iConfirm IS NOT NULL');
        $this->db->limit(40);
        $this->db->order_by('iIdPm', 'DESC');
        $query = $this->db->get();

        return $query->result();
    }

    public function getDataSodaqoh()
    {
        $this->db->select(['d.*', 'IFNULL(r.vNamaBank,"-") as bank']);
        $this->db->from($this->table . ' d');
        $this->db->join('tb_list_rekening r', 'r.iIdTp = d.iRekeningId', 'left');
        $this->db->where('d.eTypeKas = 3');
        $this->db->where('iConfirm IS NOT NULL');
        $this->db->limit(40);
        $this->db->order_by('iIdPm', 'DESC');
        $query = $this->db->get();

        return $query->result();
    }

    public function getDataByDonatur($id)
    {
        $this->db->select(['d.*', 'IFNULL(r.vNamaBank,"-") as bank', 'IFNULL(r.vRekening,"-") as rekening', 't.vNama as tipekas']);
        $this->db->from($this->table . ' d');
        $this->db->join('tb_list_rekening r', 'r.iIdTp = d.iRekeningId', 'left');
        $this->db->join('tb_list_tk t', 't.iIdTk = d.eTypeKas', 'left');
        $this->db->where(['d.iCreated' => $id]);
        $query = $this->db->get();

        return $query->result();
    }

    public function addRecord($value)
    {
        $this->db->insert($this->table, $value);
        return $this->db->affected_rows();
    }
}
