<?php

class Pengeluaran_model extends CI_Model
{
    public $table = 'tb_pengeluaran';
    public $orderDef = ['iIdPb', 'iTotal', 'dDate', 'iTipe', null, null, null];

    private function preData()
    {
        $this->db->select(['d.*', 'k.vNama as tipeKas', 'c.vNama as userNama', 'h.iConfirm as konfirm']);
        $this->db->from($this->table . ' d');
        $this->db->join('tb_list_tk k', 'k.iIdTk = d.iTipe', 'left');
        $this->db->join('tb_user c', 'c.iIdUser = d.iCreated', 'left');
        $this->db->join('tb_kas_hd h', 'h.dDate = d.dDate', 'left');

        if (isset($_POST['search']['value'])) {
            $this->db->like('d.dDate', $_POST['search']['value']);
            $this->db->or_like('d.iTotal', $_POST['search']['value']);
        }

        if (isset($_POST['order'])) {
            $this->db->order_by($this->orderDef[$_POST['order'][0]['column']], $_POST['order'][0]['dir']);
            $this->db->order_by('iTipe', 'ASC');
        } else {
            $this->db->order_by('iIdKasDt', 'ASC');
            $this->db->order_by('iTipe', 'ASC');
        }
    }

    public function createData()
    {
        $this->preData();
        if ($_POST['length'] != -1) {
            $this->db->limit($_POST['length'], $_POST['start']);
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function getRows()
    {
        $this->preData();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function getAllData()
    {
        $this->db->select('*');
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

    public function getDataById($id)
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['iIdPb' => $id]);
        $query = $this->db->get();

        return $query->row();
    }

    public function addRecord($value)
    {
        $this->db->insert($this->table, $value);
        return $this->db->affected_rows();
    }

    public function editRecord($id, $data)
    {
        $this->db->where('iIdPb', $id);
        $this->db->update($this->table, $data);
        return $this->db->affected_rows();
    }
}
