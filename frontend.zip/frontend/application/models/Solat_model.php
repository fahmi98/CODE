<?php

class Solat_model extends CI_Model
{
    public $table = 'tb_jadwal_solat';
    public $orderDef = ['iIdSholat', 'vKhatib', 'vImam', 'vMateri', 'dDate', 'tMulai', 'eTipe', null, null];

    public function getDataLimit()
    {
        $begin = date('Y-m-d', strtotime('-3 days'));
        $end = date('Y-m-d', strtotime('+4 days'));
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('dDate >= ', $begin);
        $this->db->where('dDate <= ', $end);
        $this->db->order_by('dDate', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function getDataMonth()
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('MONTH(dDate)', date('m'));
        $this->db->where('YEAR(dDate)', date('Y'));
        $this->db->order_by('dDate', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }
}
