<?php

class Kegiatan_model extends CI_Model
{
    public $table = 'tb_kegiatan';

    public function getCount()
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('MONTH(dDate)', date('m'));
        $this->db->where('YEAR(dDate)', date('Y'));
        $query = $this->db->get()->num_rows();
        return $query;
    }

    public function getHomePage()
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('MONTH(dDate)', date('m'));
        $this->db->where('YEAR(dDate)', date('Y'));
        $this->db->where('vTable != "Pengajian"');
        $this->db->limit(6);
        $this->db->order_by('dDate', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }

    public function getDataCalendar()
    {
        $dnow = date('Y-m-d');
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('dDate >=', $dnow);

        $query = $this->db->get();
        return $query->result();
    }
}
