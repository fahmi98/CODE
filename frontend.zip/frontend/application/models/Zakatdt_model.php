<?php

class Zakatdt_model extends CI_Model
{
    public $table = 'tb_zakat_dt';
    public $orderDef = ['iIdZakatDt', 'vNama', 'eTipe', 'iUang', 'dBeras', 'h.iTahunH', null, null];

    public function getDataByHeader($id)
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['iIdZakat' => $id]);
        $query = $this->db->get();

        return $query->result();
    }
}
