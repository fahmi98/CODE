<?php

class Rekening_model extends CI_Model
{
    public $table = 'tb_list_rekening';
    public $orderDef = ['iIdTp', 'vNamaBank', 'vNamaPemilik', 'vRekening', null];


    public function getDataById($id)
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['iIdTp' => $id]);
        $query = $this->db->get();

        return $query->row();
    }

    public function getListRek()
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['eStatus' => 'Y']);
        $query = $this->db->get();

        return $query->result();
    }
}
