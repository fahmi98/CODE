<?php

class Users_model extends CI_Model
{
    public $table = 'tb_user';
    public $orderDef = ['iIdUser', 'vNama', 'vEmail', null, 'eGender', null];

    public function getDataLogin($email)
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('vUsername', $email);
        $this->db->or_where('vEmail', $email);

        $query = $this->db->get();
        return $query;
    }

    public function getDataById($id)
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['iIdUser' => $id]);
        $query = $this->db->get();

        return $query->row();
    }

    public function editRecord($id, $data)
    {
        $this->db->where('iIdUser', $id);
        $this->db->update($this->table, $data);
        return $this->db->affected_rows();
    }
}
