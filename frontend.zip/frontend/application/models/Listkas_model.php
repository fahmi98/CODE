<?php

class Listkas_model extends CI_Model
{
    public $table = 'tb_list_tk';
    public $orderDef = ['iIdTk', 'vNama', 'eTipe', null];

    public function getDataById($id)
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['iIdTk' => $id]);
        $query = $this->db->get();

        return $query->row();
    }

    public function getCheckTipe($id)
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['iIdTk' => $id]);
        $query = $this->db->get()->row();

        if (($query->eTipe == 'DONASI') || ($query->eTipe == 'BOTI')) {
            return true;
        } else {
            return false;
        }
    }

    public function getListIN()
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['eTipe' => 'IN']);
        $this->db->order_by('iIdTk', 'ASC');
        $query = $this->db->get();

        return $query->result();
    }

    public function getListBOTI()
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['eTipe' => 'BOTI']);
        $query = $this->db->get();

        return $query->row();
    }

    public function getListDANA()
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['eTipe' => 'DANA']);
        $this->db->order_by('iIdTk', 'ASC');
        $query = $this->db->get();

        return $query->result();
    }

    public function getListOUT()
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['eTipe' => 'OUT']);
        $this->db->order_by('iIdTk', 'ASC');
        $query = $this->db->get();

        return $query->result();
    }
}
