<?php

class Zakat_model extends CI_Model
{
    public $table = 'tb_zakat_hd';
    public $orderDef = ['iIdZakat', 'iTahunH', 'yTahun', 'iTotalUang', 'dTotalBeras', null, null, null];

    public function getDataById($id)
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['iIdZakat' => $id]);
        $query = $this->db->get();

        return $query->row();
    }

    public function getLastRecord()
    {
        $this->db->select(['*']);
        $this->db->from($this->table);
        $this->db->order_by('iIdZakat', 'DESC');
        $query = $this->db->get();

        return $query->row();
    }
}
