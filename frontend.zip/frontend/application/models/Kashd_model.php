<?php

class Kashd_model extends CI_Model
{
    public $table = 'tb_kas_hd';
    public $orderDef = ['iIdKas', 'iTotalKas', 'dDate', null, null];

    public function getDataLastMonth()
    {
        $dnow = date('Y-m-d');
        $dend = date('Y-m-d', strtotime('-30 day'));
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('dDate BETWEEN "' . $dend . '" AND "' . $dnow . '"');
        $this->db->where('iTotalKas >', 0);
        $query = $this->db->get();

        return $query->result();
    }

    public function getCheckDate($tgl)
    {
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where(['dDate' => $tgl]);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
}
