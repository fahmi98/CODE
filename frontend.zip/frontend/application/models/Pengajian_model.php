<?php

class Pengajian_model extends CI_Model
{
    public $table = 'tb_jadwal_pengajian';
    public $orderDef = ['iIdJadwal', 'dDate', 'vTitle', 'tMulai', 'tSelesai', 'eGender', 'eUmur', null, null, null];

    public function getDataLimit()
    {
        $begin = date('Y-m-d');
        $gender = $this->session->userdata('_gender');
        $status = $this->session->userdata('_status');
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('dDate >= "' . $begin . '"');
        $this->db->where('(eGender = "S" OR eGender = "' . $gender . '")');
        $this->db->where('(eUmur = "S" OR eUmur = "' . $status . '")');
        $this->db->order_by('dDate', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }
}
