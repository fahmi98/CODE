<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Not Found</title>

    <link rel="icon" href="<?= base_url('assets/'); ?>img/title.png">
    <link href="<?= base_url('assets/'); ?>css/pas-404.css" rel="stylesheet">
</head>

<body>
    <main class='container'>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>4</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <span class='particle'>0</span>
        <article class='content'>
            <p>Damnit Not Found,</p>
            <p>You got lost in the <strong>404</strong>.</p>
            <p>
                <button onclick="javascript:window.history.go(-1)">Go back to earth.</button>
            </p>
        </article>
    </main>

</body>

</html>