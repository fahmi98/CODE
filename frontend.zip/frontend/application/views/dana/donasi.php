<!-- //bottom-grids-->
<section class="w3l-aboutblock1 py-5" id="donatur">
    <div class="container py-lg-5 py-md-3">
        <div class="title-content text-center mb-2">
            <h3 class="title-big">Donasi, Infaq & Sodaqoh</h3>
        </div>
        <div class="row mt-2">
            <div class="col-md-12">
                <?= $this->session->flashdata('message'); ?>
                <form action="<?= base_url('dana/donasi'); ?>" method="post">
                    <!-- ROW -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="donasiTanggal">Tanggal</label>
                                <input type="text" class="form-control form-date-pas" name="donasiTanggal" id="donasiTanggal" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="donasiBank">Rekening</label>
                                <select class="form-control" name="donasiBank" id="donasiBank">
                                    <?php foreach ($datarek as $rek) : ?>
                                        <option value="<?= $rek->iIdTp; ?>"><?= $rek->vNamaBank . ' - ' . $rek->vRekening; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="donasiKas">Tipe</label>
                                <select class="form-control" name="donasiKas" id="donasiKas">
                                    <?php foreach ($dlist as $list) : ?>
                                        <option value="<?= $list->iIdTk; ?>"><?= $list->vNama; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="donasiJumlah">Jumlah</label>
                                <input type="text" class="form-control only-number" name="donasiJumlah" id="donasiJumlah" required maxlength="11">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="ex">&nbsp;</label>
                                <button class="btn btn-success btn-block" type="submit" name="btn-change-pass">Submit</button>
                            </div>
                        </div>
                    </div>
                    <!-- END ROW -->
                    <hr>
                </form>
            </div>
        </div>

        <div class="title-content text-center mb-2 mt-4">
            <h3 class="title-big">Riwayat</h3>
        </div>
        <div class="row mt-2">
            <div class="col-md-12">
                <table class="table table-stripped table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center">Tanggal</th>
                            <th class="text-center">Rekening</th>
                            <th class="text-center">Bank</th>
                            <th class="text-center">Total</th>
                            <th class="text-center">Tipe</th>
                            <th class="text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($donatur as $dn) : ?>
                            <tr>
                                <td class="text-center"><?= tanggal_indo($dn->dDate); ?></td>
                                <td class="text-center"><?= $dn->rekening; ?></td>
                                <td class="text-center"><?= $dn->bank; ?></td>
                                <td class="text-center">Rp. <?= number_format($dn->iTotal); ?></td>
                                <td class="text-center"><?= $dn->tipekas; ?></td>
                                <td class="text-center"><?= ($dn->iConfirm) ? 'Approved' : 'Menunggu'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>