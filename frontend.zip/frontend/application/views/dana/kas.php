<!-- //bottom-grids-->
<section class="w3l-aboutblock1 py-5" id="kasbulanan">
    <div class="container py-lg-5 py-md-3">
        <div class="title-content text-center mb-2">
            <h3 class="title-big">Kas Masjid At-Taufiq</h3>
        </div>
        <div class="row mt-2">
            <table class="table table-stripped table-bordered">
                <tbody>
                    <?php
                    $total = 0;
                    foreach ($danakas as $kdt) : ?>
                        <tr>
                            <td class="text-center bg-success text-white" colspan="2"><?= tanggal_indo($kdt->dDate); ?></td>
                        </tr>
                        <?php
                        $total = explode(',', $kdt->dtTotal);
                        $tipe = explode(',', $kdt->tipeKas);
                        for ($x = 0; $x < count($total); $x++) : ?>
                            <tr>
                                <td class="text-center"><?= $tipe[$x]; ?></td>
                                <td class="text-center">Rp. <?= inOutCash($total[$x]); ?></td>
                            </tr>
                        <?php endfor; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>