<!-- //bottom-grids-->
<section class="w3l-aboutblock1 py-5" id="donatur">
    <div class="container py-lg-5 py-md-3">
        <div class="title-content text-center mb-2">
            <h3 class="title-big">Dana Sodaqoh Masjid At-Taufiq</h3>
        </div>
        <div class="row mt-2">
            <table class="table table-stripped table-bordered">
                <thead>
                    <tr>
                        <th class="text-center">Nama</th>
                        <th class="text-center">Tanggal</th>
                        <th class="text-center">Pembayaran</th>
                        <th class="text-center">Bank</th>
                        <th class="text-center">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($donatur as $dn) : ?>
                        <tr>
                            <td class="text-center"><?= $dn->vNama; ?></td>
                            <td class="text-center"><?= tanggal_indo($dn->dDate); ?></td>
                            <td class="text-center"><?= $dn->eTipePb; ?></td>
                            <td class="text-center"><?= $dn->bank; ?></td>
                            <td class="text-center">Rp. <?= number_format($dn->iTotal); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>