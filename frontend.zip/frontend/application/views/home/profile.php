<section class="w3l-contact-7 py-5" id="contact">
    <div class="contacts-9 py-lg-5 py-md-4">
        <div class="container">
            <div class="top-map">
                <div class="row map-content-9 justify-content-center">
                    <div class="col-lg-6">
                        <h3 class="title-big mb-1 mt-1">Profile</h3>
                        <?= $this->session->flashdata('message'); ?>
                        <form action="<?= base_url('home/profile'); ?>" method="post">
                            <!-- ROW -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Nama</label>
                                        <input type="text" class="form-control" disabled value="<?= $dataProfile->vNama; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Username</label>
                                        <input type="text" class="form-control" disabled value="<?= $dataProfile->vUsername; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="text" class="form-control" disabled value="<?= $dataProfile->vEmail; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Telepon</label>
                                        <input type="text" class="form-control" disabled value="+62 <?= $dataProfile->vTelepon; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Jenis Kelamin</label>
                                        <input type="text" class="form-control" disabled value="<?= genderStatus($dataProfile->eGender); ?>">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Tanggal Lahir</label>
                                        <input type="text" class="form-control" disabled value="<?= tanggal_indo($dataProfile->dTLahir, true); ?>">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Alamat</label>
                                        <textarea cols="30" rows="5" class="form-control" disabled><?= $dataProfile->vAlamat; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="oldPassword">Password Lama</label>
                                        <input type="password" class="form-control" name="oldPassword" id="oldPassword" maxlength="10" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="newPassword">Password Baru</label>
                                        <input type="password" class="form-control" name="newPassword" id="newPassword" maxlength="10" required>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="p-2">
                                        <button class="btn btn-success btn-block" type="submit" name="btn-change-pass">Ubah Password</button>
                                    </div>
                                </div>
                            </div>
                            <!-- END ROW -->
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>