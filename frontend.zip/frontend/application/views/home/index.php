<!-- /bottom-grids-->
<section class="w3l-aboutblock1 py-5" id="tentang">
    <div class="container py-lg-5 py-md-3">
        <div class="row">
            <div class="col-lg-6">
                <h5 class="title-small">Masjid Jami At-Taufiq</h5>
                <h3 class="title-big">Tentang Masjid</h3>
                <p class="mt-3">Kami selaku Pengurus Masjid “Jami’ At-Taufiq” merasa perlu untuk menjaga dan meningkatkan kemakmurannya sesuai amanah jama’ah. Untuk dapat memakmurkan Masjid dan jama’ahnya dengan aktifitas yang berkualitas diperlukan dana. Secara kuantitas, umat Islam berjumlah cukup banyak sehingga merupakan potensi penyumbang dana yang baik. Apabila potensi besar ini dapat dimanfaatkan, insya Allah kebutuhan dana dalam hal Memakmurkan Masjid “Jami’ At-Taufiq” dapat terpenuhi.</p>
                <p class="mt-3">Partisipasi aktif umat Islam, khususnya Jamaah Masjid Jami’ At-Taufiq diwilayah RW.08, dalam mendanai kegiatan Kemakmuran Masjid Jami’ At-Taufiq benar-benar sangat diharapkan.</p>

            </div>
            <div class="col-lg-6 mt-lg-0 mt-5">
                <img src="assets/images/banner1.jpg" alt="" class="radius-image img-fluid">
            </div>
        </div>
    </div>
</section>

<section class="w3l-bottom-grids-6 py-5">
    <div class="container py-lg-5 py-md-4 py-2">
        <div class="grids-area-hny main-cont-wthree-fea row">
            <div class="col-lg-4 col-md-6 grids-feature">
                <div class="area-box">
                    <img src="assets/images/donate.png" alt="">
                    <h4><a href="#feature" class="title-head">Donasi</a></h4>
                    <p class="mb-3">Dengan menjadi Donatur Tetap, berarti telah turut berjuang secara rutin di jalan Allah “biamwaalikum” untuk meninggikan kalimatullah dalam menda’wahkan dan mensyi’arkan Islam.</p>
                    <a href="#donate" class="btn btn-text">Donasi Sekarang</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 grids-feature mt-md-0 mt-5">
                <div class="area-box">
                    <img src="assets/images/volunteer.png" alt="">
                    <h4><a href="#feature" class="title-head">Jamaah</a></h4>
                    <p class="mb-3">Memberikan Informasi keterbukaan Laporan dan Kegiatan Rutin Masjid Jami’ At-Taufiq kepada Donatur Tetap Jamaah Masjid Jami’At-Taufiq RW.08 Kelurahan Tomang.</p>
                    <a href="http://api.whatsapp.com/send?phone=6289519215966" class="btn btn-text" target="_blank">Bergabung </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 grids-feature mt-lg-0 mt-5">
                <div class="area-box">
                    <img src="assets/images/education.png" alt="" width="52px">
                    <h4><a href="#feature" class="title-head">Kegiatan</a></h4>
                    <p class="mb-3">Aktifitas yang diselenggarkan Pengurus Masjid Jami’ At-Taufiq akan mengutamakan kualitas, nilai positif dan mampu memberi hasil yang baik bagi jamaah.</p>
                    <a href="#kegiatan" class="btn btn-text">Lihat Kegiatan </a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- //bottom-grids-->
<section class="w3l-aboutblock1 py-5" id="kasbulanan">
    <div class="container py-lg-5 py-md-3">
        <div class="title-content text-center mb-2">
            <h3 class="title-big">Kas Masjid At-Taufiq <?= tanggal_indo(date('Y-m-d', strtotime('-30 day'))); ?> - <?= tanggal_indo(date('Y-m-d')); ?></h3>
        </div>
        <div class="row mt-2">
            <table class="table table-stripped table-bordered">
                <thead>
                    <tr>
                        <th class="text-center">Tanggal</th>
                        <th class="text-center">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total = 0;
                    foreach ($kashead as $kashd) :
                        $total += $kashd->iTotalKas;
                    ?>
                        <tr>
                            <td class="text-center"><?= tanggal_indo($kashd->dDate); ?></td>
                            <td class="text-center">Rp. <?= number_format($kashd->iTotalKas); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td class="text-center"><b>Total</b></td>
                        <td class="text-center"><b>Rp. <?= number_format($total); ?></b></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</section>
<!-- stats -->
<section class="w3_stats py-5" id="kasmasjid">
    <div class="container py-lg-5 py-md-4 py-2">
        <div class="title-content text-center">
            <h3 class="title-big">Kas Masjid Bulan <?= namaBulan(date('m')); ?> <?= date('Y'); ?></h3>
        </div>
        <div class="w3-stats text-center">
            <div class="row">
                <div class="col-md-4 col-6">
                    <div class="counter">
                        <span class="fa fa-money"></span>
                        <div class="timer count-title count-number mt-3" data-to="<?= $kastotal->iTotal; ?>" data-speed="500"></div>
                        <p class="count-text ">Total Kas</p>
                    </div>
                </div>
                <div class="col-md-4 col-6">
                    <div class="counter">
                        <span class="fa fa-arrow-circle-o-up"></span>
                        <div class="timer count-title count-number mt-3" data-to="<?= $pemasukan->intotal; ?>" data-speed="500"></div>
                        <p class="count-text ">Pemasukan</p>
                    </div>
                </div>
                <div class="col-md-4 col-6">
                    <div class="counter">
                        <span class="fa fa-arrow-circle-o-down"></span>
                        <div class="timer count-title count-number mt-3" data-to="<?= abs($pengeluaran->outtotal); ?>" data-speed="500"></div>
                        <p class="count-text ">Pengeluaran</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- //stats -->
<section class="w3l-aboutblock1 py-5" id="kegiatan">
    <div class="container py-lg-5 py-md-3">
        <div class="title-content text-center">
            <h3 class="title-big">Kegiatan</h3>
        </div>
        <div class="row mt-lg-5 mt-3 pt-lg-2">
            <ul class="m-timeline">
                <?php foreach ($kegiatan as $kg) : ?>
                    <li>
                        <div class="m-timeline__date">
                            <span><?= $kg->vKeterangan; ?></span> <?= ($kg->vTable == 'Solat') ? ' - Sholat ' . $kg->vTipe : null; ?>
                        </div>

                        <p>
                            <?= tanggal_indo($kg->dDate, true) . ', ' . date('H:i', strtotime($kg->tMulai)); ?>
                        </p>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</section>
<!-- bg -->
<div class="w3l-bg py-5">
    <div class="container py-lg-5 py-md-4">
        <div class="welcome-left text-center py-lg-4">
            <span class="fa fa-heart-o"></span>
            <h3 class="title-big">Bantu Pembangunan Masjid & Sumbangan Kegiatan, Santunan Anak Yatim.</h3>
            <a href="#donate" class="btn btn-style btn-primary mt-sm-5 mt-4">Donasi</a>
        </div>
    </div>
</div>
<!-- //bg -->
<section class="w3l-index5 py-5" id="galeri">
    <div class="container py-lg-5 py-md-4">
        <div class="row">
            <div class="col-lg-4">
                <div class="img-block">
                    <a href="#">
                        <img src="assets/images/galeri/example.jpg" class="img-fluid radius-image-full" alt="image" />
                    </a>
                </div>
                <div class="img-block mt-4">
                    <a href="#"> <img src="assets/images/galeri/example.jpg" class="img-fluid radius-image-full" alt="image" />
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 mt-lg-0 mt-5">
                <div class="img-block">
                    <a href="#">
                        <img src="assets/images/galeri/example.jpg" class="img-fluid radius-image-full" alt="image" />
                    </a>
                </div>
                <div class="img-block mt-4">
                    <a href="#"> <img src="assets/images/galeri/example.jpg" class="img-fluid radius-image-full" alt="image" />
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 mt-lg-0 mt-md-5 mt-4">
                <div class="img-block">
                    <a href="#"> <img src="assets/images/galeri/example.jpg" class="img-fluid radius-image-full" alt="image" />
                    </a>
                </div>
                <div class="img-block mt-4">
                    <a href="#">
                        <img src="assets/images/galeri/example.jpg" class="img-fluid radius-image-full" alt="image" />
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>