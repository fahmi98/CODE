<section class="w3l-contact-7 py-5" id="contact">
    <div class="contacts-9 py-lg-5 py-md-4">
        <div class="container">
            <div class="top-map">
                <div class="row map-content-9 justify-content-center">
                    <div class="col-lg-6">
                        <h3 class="title-big mb-1 mt-1">Login</h3>
                        <?= $this->session->flashdata('message'); ?>
                        <form method="post" action="<?= base_url('home/login'); ?>" class="text-right">
                            <div class="form-group">
                                <label for="usernameLogin">Username Or Email</label>
                                <input type="text" class="form-control" id="usernameLogin" name="usernameLogin" placeholder="Masukan Username Atau Email" maxlength="30" required>
                                <?php echo form_error('usernameLogin'); ?>
                            </div>
                            <div class="form-group">
                                <label for="passwordLogin">Password</label>
                                <input type="password" class="form-control" id="passwordLogin" name="passwordLogin" placeholder="Masukan Password" maxlength="10" required>
                                <?php echo form_error('passwordLogin'); ?>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block btn-style mt-3">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>