<!-- //bottom-grids-->
<section class="w3l-aboutblock1 py-5" id="donatur">
    <div class="container py-lg-5 py-md-3">
        <div class="title-content text-center mb-2">
            <h3 class="title-big">Zakat <?= $dhead->iTahunH; ?>H (<?= $dhead->yTahun; ?>)</h3>
        </div>
        <div class="row mt-2">
            <table class="table table-stripped table-bordered">
                <thead>
                    <tr>
                        <th class="text-center">Nama</th>
                        <th class="text-center">Tanggal</th>
                        <th class="text-center">Uang</th>
                        <th class="text-center">Beras</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($dzakat as $dn) : ?>
                        <tr>
                            <td class="text-center"><?= $dn->vNama; ?></td>
                            <td class="text-center"><?= tanggal_indo(date('Y-m-d', strtotime($dn->tCreated))); ?></td>
                            <td class="text-center">Rp. <?= number_format($dn->iUang); ?></td>
                            <td class="text-center"><?= $dn->dBeras; ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td class="text-center" colspan="2"><b>TOTAL</b></td>
                        <td class="text-center"><b>Rp. <?= number_format($dhead->iTotalUang); ?></b></td>
                        <td class="text-center"><b><?= $dhead->dTotalBeras; ?></b></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</section>