<section class="w3-services-ab py-5" id="donate">
    <div class="container py-lg-5 py-md-4">
        <h3 class="title-big text-center mb-5">Donasi</h3>
        <div class="w3-services-grids">
            <div class="fea-gd-vv row">
                <?php
                $query = $this->db->query('SELECT * FROM tb_list_rekening WHERE eStatus = "Y"')->result();
                foreach ($query as $qr) : ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="float-lt feature-gd">
                            <div class="icon">
                                <img src="<?= base_url(); ?>assets/images/<?= $qr->vNamaBank; ?>.png" alt="" class="img-fluid">
                            </div>
                            <div class="icon-info">
                                <h5><?= $qr->vNamaPemilik; ?></h5>
                                <p> <?= $qr->vRekening; ?> (<?= $qr->vNamaBank; ?>)</p>

                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<div class="map">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d350.61065364168473!2d106.79241129862099!3d-6.170009505261411!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f65da61563b7%3A0xec1c874602b56972!2sMasjid%20Jami%20At%20Taufiq!5e0!3m2!1sid!2sid!4v1628341595192!5m2!1sid!2sid" frameborder="0" style="border:0" allowfullscreen="true" loading="lazy"></iframe>
</div>
<!-- footer 14 -->
<div class="w3l-footer-main">
    <div class="w3l-sub-footer-content">
        <footer class="footer-14">
            <div id="footers14-block">
                <div class="container">
                    <div class="footers20-content">
                        <div class="d-grid grid-col-4 grids-content" id="kontak">
                            <div class="column">
                                <h4>Alamat</h4>
                                <p>Jalan Tanjung Gedong RW.08 Kelurahan Tomang, Grogol Petamburan, Jakarta Barat</p>
                            </div>
                            <div class="column">
                                <h4>Telepon</h4>
                                <p><a href="tel:+6285882035410">+62 895-1921-5966</a></p>
                                <p><a href="tel:+6289673374408">+62 858-8203-5410</a></p>
                                <!-- <p><a href="tel:+6285961146890">+62 859-6114-6890</a></p> -->
                            </div>
                            <div class="column">
                                <h4>Email</h4>
                                <p><a href="mailto:masjid.at.taufiiq@gmail.com">masjid.at.taufiiq@gmail.com</a></p>
                            </div>
                            <div class="column">
                                <h4>Follow Us On</h4>
                                <ul>
                                    <li><a href="#facebook"><span class="fa fa-facebook" aria-hidden="true"></span></a>
                                    </li>
                                    <li><a href="#linkedin"><span class="fa fa-linkedin" aria-hidden="true"></span></a>
                                    </li>
                                    <li><a href="#twitter"><span class="fa fa-twitter" aria-hidden="true"></span></a>
                                    </li>
                                    <li><a href="#google"><span class="fa fa-google-plus" aria-hidden="true"></span></a>
                                    </li>
                                    <li><a href="#github"><span class="fa fa-github" aria-hidden="true"></span></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="footers14-bottom d-flex">
                        <div class="copyright">
                            <p>© <?= date('Y'); ?> Masjid Jami At-Taufiq. All rights reserved. Design by <a href="https://w3layouts.com/" target="_blank">W3Layouts</a></p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- move top -->
            <button onclick="topFunction()" id="movetop" title="Go to top">
                &uarr;
            </button>
            <script>
                // When the user scrolls down 20px from the top of the document, show the button
                window.onscroll = function() {
                    scrollFunction()
                };

                function scrollFunction() {
                    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                        document.getElementById("movetop").style.display = "block";
                    } else {
                        document.getElementById("movetop").style.display = "none";
                    }
                }

                // When the user clicks on the button, scroll to the top of the document
                function topFunction() {
                    document.body.scrollTop = 0;
                    document.documentElement.scrollTop = 0;
                }
            </script>
            <!-- /move top -->

        </footer>
        <!-- Footers-14 -->
    </div>
</div>
<!-- //footer 14 -->

<script src="<?= base_url(); ?>assets/js/jquery-3.3.1.min.js"></script> <!-- Common jquery plugin -->

<!-- <script src="<?= base_url(); ?>assets/js/theme-change.js"></script> -->
<!-- theme switch js (light and dark)-->
<script src="<?= base_url(); ?>assets/js/owl.carousel.js"></script>

<!-- script for banner slider-->
<script>
    $(document).ready(function() {
        $('.owl-one').owlCarousel({
            loop: true,
            dots: false,
            margin: 0,
            nav: true,
            responsiveClass: true,
            autoplay: true,
            autoplayTimeout: 5000,
            autoplaySpeed: 1000,
            autoplayHoverPause: false,
            responsive: {
                0: {
                    items: 1
                },
                480: {
                    items: 1
                },
                667: {
                    items: 1
                },
                1000: {
                    items: 1
                }
            }
        })
    })
</script>
<!-- //script -->

<!-- script for tesimonials carousel slider -->
<script>
    $(document).ready(function() {
        $("#owl-demo1").owlCarousel({
            loop: true,
            margin: 20,
            nav: false,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1
                },
                736: {
                    items: 1
                },
                1000: {
                    items: 2,
                    loop: false
                }
            }
        })
    })
</script>
<!-- //script for tesimonials carousel slider -->

<script src="<?= base_url(); ?>assets/js/counter.js"></script>

<!--/MENU-JS-->
<script>
    $(window).on("scroll", function() {
        var scroll = $(window).scrollTop();

        if (scroll >= 80) {
            $("#site-header").addClass("nav-fixed");
        } else {
            $("#site-header").removeClass("nav-fixed");
        }
    });

    //Main navigation Active Class Add Remove
    $(".navbar-toggler").on("click", function() {
        $("header").toggleClass("active");
    });
    $(document).on("ready", function() {
        if ($(window).width() > 991) {
            $("header").removeClass("active");
        }
        $(window).on("resize", function() {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
        });
    });
</script>
<!--//MENU-JS-->

<!-- disable body scroll which navbar is in active -->
<script>
    $(function() {
        $('.navbar-toggler').click(function() {
            $('body').toggleClass('noscroll');
        })
    });
</script>
<!-- //disable body scroll which navbar is in active -->

<!--bootstrap-->
<script src="<?= base_url(); ?>assets/js/bootstrap.min.js"></script>
<!-- //bootstrap-->
<script>
    $(document).on('focus', '.form-date-pas', function() {
        $(this).attr('type', 'date');
    });

    $(document).on('blur', '.form-date-pas', function() {
        $(this).attr('type', 'text');
    });

    $(document).on('keypress', '.only-number', function() {
        return isNumberKey($(this).val());
    });

    function isNumberKey(evt) {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

        return true;
    }
</script>
</body>

</html>