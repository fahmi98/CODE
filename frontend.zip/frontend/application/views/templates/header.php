<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Masjid Jami At-Taufiq - <?= $title; ?></title>
    <link rel="icon" href="<?= base_url(); ?>assets/images/title.png">
    <link href="//fonts.googleapis.com/css2?family=DM+Sans:wght@400;700&display=swap" rel="stylesheet">

    <!-- Template CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/style-starter.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/timeline.css">
</head>

<body>
    <!--header-->
    <header id="site-header" class="fixed-top">
        <div class="container">
            <nav class="navbar navbar-expand-lg stroke">
                <h1><a class="navbar-brand mr-lg-5" href="<?= base_url(); ?>">
                        <img src="<?= base_url(); ?>assets/images/title.png" alt="Your logo" title="Masjid At-Taufiq" />
                    </a></h1>
                <!-- if logo is image enable this   
    <a class="navbar-brand" href="#">
        <img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
    </a> -->
                <button class="navbar-toggler  collapsed bg-gradient" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
                    <span class="navbar-toggler-icon fa icon-close fa-times"></span>
                    </span>
                </button>

                <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                    <ul class="navbar-nav w-100">
                        <li class="nav-item active">
                            <a class="nav-link" href="<?= base_url(); ?>">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item @@about__active">
                            <a class="nav-link" href="#tentang">Tentang</a>
                        </li>
                        <li class="nav-item @@contact__active">
                            <a class="nav-link" href="#galeri">Galeri</a>
                        </li>
                        <li class="nav-item dropdown @@pages__active">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Dana<span class="fa fa-angle-down"></span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                <a class="dropdown-item @@causes__active" href="<?= base_url('dana/kas'); ?>">Kas Masjid</a>
                                <a class="dropdown-item @@causes__active" href="<?= base_url('dana'); ?>">Donasi</a>
                                <a class="dropdown-item @@donate__active" href="<?= base_url('dana/infaq'); ?>">Infaq</a>
                                <a class="dropdown-item @@error__active" href="<?= base_url('dana/sodaqoh'); ?>">Sodaqoh</a>
                            </div>
                        </li>
                        <li class="nav-item dropdown @@pages__active">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Kegiatan<span class="fa fa-angle-down"></span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                <a class="dropdown-item @@donate__active" href="<?= base_url('kegiatan/sholat'); ?>">Sholat</a>
                                <a class="dropdown-item @@error__active" href="<?= base_url('kegiatan/acara'); ?>">Acara Masjid</a>
                            </div>
                        </li>
                        <li class="nav-item @@contact__active">
                            <a class="nav-link" href="<?= base_url('zakat'); ?>">Zakat</a>
                        </li>
                        <li class="nav-item @@contact__active">
                            <a class="nav-link" href="#kontak">Kontak</a>
                        </li>
                        <?php if (isset($_SESSION['_username'])) { ?>
                            <li class="ml-lg-auto mr-lg-0 m-auto nav-item dropdown @@pages__active">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Hai, <?= $_SESSION['_nama']; ?><span class="fa fa-angle-down"></span>
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                    <a class="dropdown-item @@causes__active" href="<?= base_url('home/profile'); ?>">Profile</a>
                                    <a class="dropdown-item @@causes__active" href="<?= base_url('kegiatan'); ?>">Pengajian</a>
                                    <a class="dropdown-item @@donate__active" href="<?= base_url('dana/donasi'); ?>">Donasi</a>
                                    <a class="dropdown-item @@error__active" href="<?= base_url('home/logout'); ?>">Logout</a>
                                </div>
                            </li>
                        <?php } else { ?>
                            <li class="ml-lg-auto mr-lg-0 m-auto">
                                <a class="nav-link" href="<?= base_url('home/login'); ?>"><i class="fa fa-user"></i> Login</a>
                            </li>
                        <?php } ?>
                        <li class="align-self">
                            <a href="#donate" class="btn btn-style btn-primary ml-lg-3 mr-lg-2"><span class="fa fa-heart mr-1"></span> Donate</a>
                        </li>
                    </ul>
                </div>
                <!-- toggle switch for light and dark theme -->
                <!-- <div class="mobile-position">
                    <nav class="navigation">
                        <div class="theme-switch-wrapper">
                            <label class="theme-switch" for="checkbox">
                                <input type="checkbox" id="checkbox">
                                <div class="mode-container">
                                    <i class="gg-sun"></i>
                                    <i class="gg-moon"></i>
                                </div>
                            </label>
                        </div>
                    </nav>
                </div> -->
                <!-- //toggle switch for light and dark theme -->
            </nav>
        </div>
    </header>
    <!-- //header -->
    <!-- main-slider -->
    <section class="w3l-main-slider" id="home">
        <div class="companies20-content">
            <div class="owl-one owl-carousel owl-theme">
                <div class="item">
                    <li>
                        <div class="slider-info banner-view bg bg2">
                            <div class="banner-info">
                                <div class="container">
                                    <div class="banner-info-bg text-left"></div>
                                </div>
                            </div>
                        </div>
                    </li>
                </div>
                <div class="item">
                    <li>
                        <div class="slider-info  banner-view banner-top1 bg bg2">
                            <div class="banner-info">
                                <div class="container">
                                    <div class="banner-info-bg text-left"></div>
                                </div>
                            </div>
                        </div>
                    </li>
                </div>
                <div class="item">
                    <li>
                        <div class="slider-info banner-view banner-top2 bg bg2">
                            <div class="banner-info">
                                <div class="container">
                                    <div class="banner-info-bg text-left"></div>
                                </div>
                            </div>
                        </div>
                    </li>
                </div>
                <!-- <div class="item">
                <li>
                    <div class="slider-info banner-view banner-top3 bg bg2">
                        <div class="banner-info">
                            <div class="container">
                                <div class="banner-info-bg text-left"></div>
                            </div>
                        </div>
                    </div>
                </li>
            </div> -->
            </div>
        </div>
    </section>
    <!-- /main-slider -->
    <!-- banner image bottom shape -->
    <div class="position-relative">
        <div class="shape overflow-hidden">
            <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor">
                </path>
            </svg>
        </div>
    </div>
    <!-- //banner image bottom shape -->
    <!-- home page block1 -->
    <section class="homeblock1">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-6 col-sm-12">
                    <div class="box-wrap">
                        <h4><a href="#">04:43<br>Subuh</a></h4>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-12 mt-md-0 mt-sm-4 mt-3">
                    <div class="box-wrap">
                        <h4><a href="#">06:03<br>Terbit</a></h4>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-12 mt-md-0 mt-sm-4 mt-3">
                    <div class="box-wrap">
                        <h4><a href="#">11:59<br>Dzuhur</a></h4>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-12 mt-lg-0 mt-sm-4 mt-3">
                    <div class="box-wrap">
                        <h4><a href="#">15:21<br>Ashar</a></h4>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-12 mt-lg-0 mt-sm-4 mt-3">
                    <div class="box-wrap">
                        <h4><a href="#">17:55<br>Maghrib</a></h4>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-12 mt-lg-0 mt-sm-4 mt-3">
                    <div class="box-wrap">
                        <h4><a href="#">19:07<br>Isya</a></h4>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //home page block1 -->