<div class="w3-services py-5">
    <div class="container py-lg-4 py-md-3">
        <div class="title-content text-center">
            <h3 class="title-big">Jadwal Acara Masjid At-Taufiq</h3>
        </div>
        <div class="row w3-services-grids">
            <?php foreach ($acara as $ac) : ?>
                <div class="col-lg-4 col-md-6 causes-grid">
                    <div class="causes-grid-info <?= ($ac->dDate < date('Y-m-d')) ? 'bg-warning' : null; ?>">
                        <a href="#" class="cause-title-wrap">
                            <p class="title"><?= tanggal_indo($ac->dDate); ?>, <?= date('H:i', strtotime($ac->tMulai)); ?></p>
                            <h4 class="cause-title"><?= $ac->vTitle; ?></h4>
                            <p class="counter-inherit"><?= $ac->vKeterangan; ?></p>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<section class="w3l-aboutblock2" id="story">
    <div class="py-5">
        <div class="container py-lg-4 py-md-3">
            <div class="cwp4-two">
                <div class="cwp4-text">
                    <h3 class="title-big">Kegiatan Acara <?= namaBulan(date('m')); ?> <?= date('Y'); ?></h3>
                    <ul class="cont-4 mt-4">
                        <?php foreach ($bulanan as $bl) : ?>
                            <li><span class="fa fa-calendar"></span><?= tanggal_indo($bl->dDate, true); ?> - <?= $bl->vTitle; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>