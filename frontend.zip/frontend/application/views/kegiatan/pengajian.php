<section class="w3l-aboutblock2" id="story">
    <div class="py-5">
        <div class="container py-lg-4 py-md-3">
            <div class="list-group">
                <?php foreach ($acara as $bl) :
                    $time = cekPengajian($bl->tMulai, $bl->tSelesai);
                ?>
                    <a <?= ($time == "BERLANGSUNG") ? 'href="' . $bl->vLink . '"' : null; ?> class="list-group-item list-group-item-action flex-column align-items-start <?= ($time == "BERLANGSUNG") ? 'active' : null; ?>" target="_blank">
                        <div class="d-flex w-100 justify-content-between">
                            <h5 class="mb-1"><?= tanggal_indo($bl->dDate, true); ?></h5>
                            <small class="text-muted"><?= date('H:i', strtotime($bl->tMulai)); ?> WIB</small>
                        </div>
                        <p class="mb-1"><?= $bl->vTitle; ?></p>
                        <small class="text-muted"><?= $time; ?></small>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>