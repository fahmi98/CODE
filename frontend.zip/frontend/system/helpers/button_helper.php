<?php
function btnUpRbac($id, $sts)
{
    $button = '';
    $update = '<a href="' . base_url('rbac/update/' . $id) . '" class="btn btn-sm btn-success"><i class="fas fa-edit"></i></a>';
    $active = '<button type="button" data-id="' . $id . '" class="btn btn-sm btn-danger btn-rbac-ban"><i class="fas fa-ban"></i></button>';
    $nonactive = '<button type="button" data-id="' . $id . '" class="btn btn-sm btn-warning btn-rbac-recovery"><i class="fas fa-sync-alt"></i></button>';

    $button = $update;
    if ($sts == "Y") {
        $button .= $active;
    } else if ($sts == "T") {
        $button .= $nonactive;
    }

    return $button;
}

function btnUpRoute($id, $sts)
{
    $button = '';
    $update = '<a href="' . base_url('route/update/' . $id) . '" class="btn btn-sm btn-success"><i class="fas fa-edit"></i></a>';
    $active = '<button type="button" data-id="' . $id . '" class="btn btn-sm btn-danger btn-route-ban"><i class="fas fa-ban"></i></button>';
    $nonactive = '<button type="button" data-id="' . $id . '" class="btn btn-sm btn-warning btn-route-recovery"><i class="fas fa-sync-alt"></i></button>';

    $button = $update;
    if ($sts == "Y") {
        $button .= $active;
    } else if ($sts == "T") {
        $button .= $nonactive;
    }

    return $button;
}

function btnUpRekening($id, $sts)
{
    $button = '';
    $update = '<a href="' . base_url('rekening/update/' . $id) . '" class="btn btn-sm btn-success"><i class="fas fa-edit"></i></a>';
    $active = '<button type="button" data-id="' . $id . '" class="btn btn-sm btn-danger btn-rekening-ban"><i class="fas fa-ban"></i></button>';
    $nonactive = '<button type="button" data-id="' . $id . '" class="btn btn-sm btn-warning btn-rekening-recovery"><i class="fas fa-sync-alt"></i></button>';

    $button = $update;
    if ($sts == "Y") {
        $button .= $active;
    } else if ($sts == "T") {
        $button .= $nonactive;
    }

    return $button;
}

function buttonKasdt($switch, $tipe, $id)
{
    $button = '';
    if ($switch) {
        $list = ['IN', 'BOTI'];
        if (in_array($tipe, $list)) {
            $update = '<a href="' . base_url('kasdt/update/' . $id) . '" class="btn btn-sm btn-success"><i class="fas fa-edit"></i></a>';
        } else if ($tipe == 'DANA') {
            $update = '<a href="' . base_url('pemasukan') . '" class="btn btn-sm btn-info"><i class="fas fa-eye"></i></a>';
        } else if ($tipe == 'OUT') {
            $update = '<a href="' . base_url('pengeluaran') . '" class="btn btn-sm btn-info"><i class="fas fa-eye"></i></a>';
        } else {
            $update = '<a href="' . base_url('zakat') . '" class="btn btn-sm btn-info"><i class="fas fa-eye"></i></a>';
        }
        $button = $update;
    } else {
        $button = '<button type="button" class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></button>';
    }

    return $button;
}

function buttonPemasukan($up, $confirm, $id, $approve)
{
    $button = '';
    $update = '<a href="' . base_url('pemasukan/update/' . $id) . '" class="btn btn-sm btn-success"><i class="fas fa-edit"></i></a>';
    $app = '<button type="button" data-id="' . $id . '" class="btn btn-sm btn-info btn-pemasukan-confirm"><i class="fas fa-check"></i></button>';

    if ($up) {
        $button .= $update;
        if ($confirm) {
            if ($approve < 1) {
                $button .= $app;
            }
        }
    } else {
        $button = '<button type="button" class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></button>';
    }
    return $button;
}
