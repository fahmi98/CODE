<?php
function userRole($role)
{
    $drole = [1 => 'Ketua', 'Bendahara', 'Sekertaris', 'Admin', 'Member'];
    $rolename = $drole[$role];

    return $rolename;
}

function tipeKasSumbangan($tkas)
{
    $sum = [1 => 'Donasi', 'Infaq', 'Sodaqoh'];
    if ($tkas > 0) {
        return $sum[$tkas];
    } else {
        return 'Sumbangan';
    }
}
