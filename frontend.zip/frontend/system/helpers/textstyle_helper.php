<?php

function inOutCash($cash)
{
    if ($cash > 0) {
        $text = '<span class="text-success"><i class="fa fa-caret-up"></i> ' . number_format($cash) . '</span>';
    } else if ($cash < 0) {
        $text = '<span class="text-danger"><i class="fa fa-caret-down"></i> ' . number_format($cash) . '</span>';
    } else {
        $text = null;
    }

    return $text;
}
