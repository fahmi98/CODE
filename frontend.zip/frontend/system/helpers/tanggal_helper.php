<?php
function tanggal_indo($tanggal, $cetak_hari = false)
{
    if ($tanggal == "0000-00-00") {
        $tgl_indo = "Unknown";
        return $tgl_indo;
    }
    $hari = array(
        1 =>    'Senin',
        'Selasa',
        'Rabu',
        'Kamis',
        'Jumat',
        'Sabtu',
        'Minggu'
    );

    $bulan = array(
        1 =>   'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    );
    $split       = explode('-', $tanggal);
    $tgl_indo = $split[2] . ' ' . $bulan[(int)$split[1]] . ' ' . $split[0];

    if ($cetak_hari) {
        $num = date('N', strtotime($tanggal));
        return $hari[$num] . ', ' . $tgl_indo;
    }
    return $tgl_indo;
}

function namaBulan($bl)
{
    $bulan = array(
        1 =>   'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    );

    return $bulan[intval($bl)];
}

function cekMonth($tanggal)
{
    $now = date('Y-m');
    $tgt = date('Y-m', strtotime($tanggal));

    if ($now == $tgt) {
        return true;
    } else {
        return false;
    }
}

function cekPengajian($ml, $ed)
{
    $start = date('H:i:s');

    if (($ml <= $start) && ($ed > $start)) {
        return 'BERLANGSUNG';
    } else if ($ml > $start) {
        return 'BELUM DIMULAI';
    } else if ($ed < $start) {
        return 'SELESAI';
    }
}
