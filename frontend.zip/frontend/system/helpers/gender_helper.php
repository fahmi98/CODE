<?php
function genderStatus($gend)
{
    $gn = [
        'L' => 'Laki-Laki',
        'P' => 'Perempuan',
        'S' => 'Pria & Wanita'
    ];

    return $gn[$gend];
}

function usiaStatus($u)
{
    $um = [
        'S' => 'Semua Umur',
        'D' => 'Dewasa',
        'R' => 'Remaja',
        'A' => 'Anak-anak'
    ];

    return $um[$u];
}
